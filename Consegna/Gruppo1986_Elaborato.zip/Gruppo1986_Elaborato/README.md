# ProgettoBasiDiDati
Progetto del corso di Basi di Dati

Nella cartella sono presenti:
- il backup del database
- l'applicazione

Non sono necessarie credenziali d'accesso.
Baster� fare il restore del database sulla propria macchina.