﻿
namespace StreaminVideoApplication
{
    partial class Rimuovere
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rimuoviButton = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.account2Box = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.utenteBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.rimuovi2Button = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.nomeBox = new System.Windows.Forms.TextBox();
            this.cfBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.indietroButton = new System.Windows.Forms.Button();
            this.accountLabel = new System.Windows.Forms.Label();
            this.utenteLabel = new System.Windows.Forms.Label();
            this.abbLabel = new System.Windows.Forms.Label();
            this.rimuovi3Button = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.codiceBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rimuoviButton
            // 
            this.rimuoviButton.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.rimuoviButton.Location = new System.Drawing.Point(13, 380);
            this.rimuoviButton.Name = "rimuoviButton";
            this.rimuoviButton.Size = new System.Drawing.Size(75, 23);
            this.rimuoviButton.TabIndex = 50;
            this.rimuoviButton.Text = "Rimuovi";
            this.rimuoviButton.UseVisualStyleBackColor = true;
            this.rimuoviButton.Click += new System.EventHandler(this.rimuoviButton_Click);
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(277, 320);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 13);
            this.label12.TabIndex = 49;
            this.label12.Text = "Inserisci nome account";
            // 
            // account2Box
            // 
            this.account2Box.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.account2Box.Location = new System.Drawing.Point(280, 336);
            this.account2Box.Name = "account2Box";
            this.account2Box.Size = new System.Drawing.Size(226, 20);
            this.account2Box.TabIndex = 48;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 320);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(107, 13);
            this.label10.TabIndex = 47;
            this.label10.Text = "Inserisci nome utente";
            // 
            // utenteBox
            // 
            this.utenteBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.utenteBox.Location = new System.Drawing.Point(12, 336);
            this.utenteBox.Name = "utenteBox";
            this.utenteBox.Size = new System.Drawing.Size(227, 20);
            this.utenteBox.TabIndex = 46;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(9, 297);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 20);
            this.label11.TabIndex = 45;
            this.label11.Text = "Rimuovi Utente:";
            // 
            // rimuovi2Button
            // 
            this.rimuovi2Button.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.rimuovi2Button.Location = new System.Drawing.Point(12, 214);
            this.rimuovi2Button.Name = "rimuovi2Button";
            this.rimuovi2Button.Size = new System.Drawing.Size(75, 23);
            this.rimuovi2Button.TabIndex = 42;
            this.rimuovi2Button.Text = "Rimuovi";
            this.rimuovi2Button.UseVisualStyleBackColor = true;
            this.rimuovi2Button.Click += new System.EventHandler(this.rimuovi2Button_Click);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(136, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 13);
            this.label3.TabIndex = 34;
            this.label3.Text = "Inserisci nome account";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 162);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 33;
            this.label2.Text = "Inserisci CF";
            // 
            // nomeBox
            // 
            this.nomeBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.nomeBox.Location = new System.Drawing.Point(139, 178);
            this.nomeBox.Name = "nomeBox";
            this.nomeBox.Size = new System.Drawing.Size(226, 20);
            this.nomeBox.TabIndex = 29;
            // 
            // cfBox
            // 
            this.cfBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cfBox.Location = new System.Drawing.Point(13, 178);
            this.cfBox.Name = "cfBox";
            this.cfBox.Size = new System.Drawing.Size(100, 20);
            this.cfBox.TabIndex = 28;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 20);
            this.label1.TabIndex = 27;
            this.label1.Text = "Rimuovi Titolare Account:";
            // 
            // indietroButton
            // 
            this.indietroButton.Location = new System.Drawing.Point(1, 1);
            this.indietroButton.Name = "indietroButton";
            this.indietroButton.Size = new System.Drawing.Size(75, 23);
            this.indietroButton.TabIndex = 26;
            this.indietroButton.Text = "<-- Indietro";
            this.indietroButton.UseVisualStyleBackColor = true;
            this.indietroButton.Click += new System.EventHandler(this.indietroButton_Click);
            // 
            // accountLabel
            // 
            this.accountLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.accountLabel.AutoSize = true;
            this.accountLabel.Location = new System.Drawing.Point(101, 219);
            this.accountLabel.Name = "accountLabel";
            this.accountLabel.Size = new System.Drawing.Size(0, 13);
            this.accountLabel.TabIndex = 52;
            // 
            // utenteLabel
            // 
            this.utenteLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.utenteLabel.AutoSize = true;
            this.utenteLabel.Location = new System.Drawing.Point(113, 385);
            this.utenteLabel.Name = "utenteLabel";
            this.utenteLabel.Size = new System.Drawing.Size(0, 13);
            this.utenteLabel.TabIndex = 53;
            // 
            // abbLabel
            // 
            this.abbLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.abbLabel.AutoSize = true;
            this.abbLabel.Location = new System.Drawing.Point(114, 547);
            this.abbLabel.Name = "abbLabel";
            this.abbLabel.Size = new System.Drawing.Size(0, 13);
            this.abbLabel.TabIndex = 61;
            // 
            // rimuovi3Button
            // 
            this.rimuovi3Button.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.rimuovi3Button.Location = new System.Drawing.Point(14, 542);
            this.rimuovi3Button.Name = "rimuovi3Button";
            this.rimuovi3Button.Size = new System.Drawing.Size(75, 23);
            this.rimuovi3Button.TabIndex = 59;
            this.rimuovi3Button.Text = "Rimuovi";
            this.rimuovi3Button.UseVisualStyleBackColor = true;
            this.rimuovi3Button.Click += new System.EventHandler(this.rimuovi3Button_Click);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 482);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(148, 13);
            this.label7.TabIndex = 56;
            this.label7.Text = "Inserisci codice abbonamento";
            // 
            // codiceBox
            // 
            this.codiceBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.codiceBox.Location = new System.Drawing.Point(13, 498);
            this.codiceBox.Name = "codiceBox";
            this.codiceBox.Size = new System.Drawing.Size(227, 20);
            this.codiceBox.TabIndex = 55;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(10, 459);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 20);
            this.label8.TabIndex = 54;
            this.label8.Text = "Rimuovi Utente:";
            // 
            // Rimuovere
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 613);
            this.Controls.Add(this.abbLabel);
            this.Controls.Add(this.rimuovi3Button);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.codiceBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.utenteLabel);
            this.Controls.Add(this.accountLabel);
            this.Controls.Add(this.rimuoviButton);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.account2Box);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.utenteBox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.rimuovi2Button);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nomeBox);
            this.Controls.Add(this.cfBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.indietroButton);
            this.Name = "Rimuovere";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rimuovere";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button rimuoviButton;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox account2Box;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox utenteBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button rimuovi2Button;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nomeBox;
        private System.Windows.Forms.TextBox cfBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button indietroButton;
        private System.Windows.Forms.Label accountLabel;
        private System.Windows.Forms.Label utenteLabel;
        private System.Windows.Forms.Label abbLabel;
        private System.Windows.Forms.Button rimuovi3Button;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox codiceBox;
        private System.Windows.Forms.Label label8;
    }
}